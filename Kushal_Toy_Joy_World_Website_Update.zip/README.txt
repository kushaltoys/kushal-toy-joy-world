KUSHAL TOY JOY WORLD WEBSITE UPDATE

Upload index.html AND the entire images folder to the ROOT of your GitHub repository kushaltoys/kushal-toy-joy-world on branch main. Replace the existing index.html. Keep the images folder structure intact. GitHub Pages will deploy after commit.

All toys display Contact for Best Price. Enquire Now opens an email draft because a verified store contact number/email has not been provided. Edit the contact link after adding your preferred WhatsApp number.
